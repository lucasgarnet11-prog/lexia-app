# LexIA - Asistente Legal Inteligente

Aplicación web para abogados argentinos con funcionalidades de IA para gestión de expedientes, redacción de escritos judiciales, análisis de casos y más.

## 🚀 Características

- ✅ **Gestión de expedientes y clientes**
- ✅ **Análisis de PDFs con IA** (Claude API)
- ✅ **Redacción de escritos judiciales**
- ✅ **Estrategia procesal automatizada**
- ✅ **Agenda de audiencias**
- ✅ **Redacción de cartas documento y contratos**
- ✅ **Calculadoras legales** (indemnizaciones, alimentos, accidentes)
- ✅ **Casos prácticos educativos**
- ✅ **Sistema de prueba de 7 días**
- ✅ **Integración con Mercado Pago**

## 📋 Requisitos previos

1. Cuenta en [Supabase](https://supabase.com)
2. Cuenta en [Vercel](https://vercel.com)
3. Cuenta en GitHub
4. API Key de [Claude (Anthropic)](https://console.anthropic.com)
5. Credenciales de [Mercado Pago Developers](https://www.mercadopago.com.ar/developers)

## 🛠️ Instalación y Configuración

### Paso 1: Configurar Supabase

1. Crea un nuevo proyecto en Supabase
2. Ve a **SQL Editor** y ejecuta el siguiente SQL:

```sql
-- Tabla de perfiles de usuario
CREATE TABLE perfiles (
    id UUID REFERENCES auth.users(id) PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    nombre TEXT NOT NULL,
    matricula TEXT,
    trial_end TIMESTAMP WITH TIME ZONE NOT NULL,
    suscripto BOOLEAN DEFAULT FALSE,
    subscription_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de expedientes
CREATE TABLE expedientes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES perfiles(id) ON DELETE CASCADE,
    numero TEXT,
    caratula TEXT NOT NULL,
    tipo TEXT NOT NULL,
    juzgado TEXT,
    cliente_id UUID,
    estado TEXT DEFAULT 'activo',
    fecha_inicio DATE,
    descripcion TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de clientes
CREATE TABLE clientes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES perfiles(id) ON DELETE CASCADE,
    nombre TEXT NOT NULL,
    dni TEXT,
    email TEXT,
    telefono TEXT,
    domicilio TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de audiencias
CREATE TABLE audiencias (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES perfiles(id) ON DELETE CASCADE,
    expediente_id UUID REFERENCES expedientes(id) ON DELETE CASCADE,
    titulo TEXT NOT NULL,
    fecha TIMESTAMP WITH TIME ZONE NOT NULL,
    lugar TEXT,
    tipo TEXT,
    notas TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabla de documentos generados
CREATE TABLE documentos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES perfiles(id) ON DELETE CASCADE,
    expediente_id UUID REFERENCES expedientes(id) ON DELETE SET NULL,
    tipo TEXT NOT NULL,
    titulo TEXT NOT NULL,
    contenido TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar Row Level Security (RLS)
ALTER TABLE perfiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE expedientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE audiencias ENABLE ROW LEVEL SECURITY;
ALTER TABLE documentos ENABLE ROW LEVEL SECURITY;

-- Políticas de seguridad para perfiles
CREATE POLICY "Los usuarios pueden ver su propio perfil"
    ON perfiles FOR SELECT
    USING (auth.uid() = id);

CREATE POLICY "Los usuarios pueden actualizar su propio perfil"
    ON perfiles FOR UPDATE
    USING (auth.uid() = id);

-- Políticas de seguridad para expedientes
CREATE POLICY "Los usuarios pueden ver sus expedientes"
    ON expedientes FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden crear expedientes"
    ON expedientes FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden actualizar sus expedientes"
    ON expedientes FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden eliminar sus expedientes"
    ON expedientes FOR DELETE
    USING (auth.uid() = user_id);

-- Políticas similares para clientes
CREATE POLICY "Los usuarios pueden ver sus clientes"
    ON clientes FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden crear clientes"
    ON clientes FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden actualizar sus clientes"
    ON clientes FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden eliminar sus clientes"
    ON clientes FOR DELETE
    USING (auth.uid() = user_id);

-- Políticas para audiencias
CREATE POLICY "Los usuarios pueden ver sus audiencias"
    ON audiencias FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden crear audiencias"
    ON audiencias FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden eliminar sus audiencias"
    ON audiencias FOR DELETE
    USING (auth.uid() = user_id);

-- Políticas para documentos
CREATE POLICY "Los usuarios pueden ver sus documentos"
    ON documentos FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden crear documentos"
    ON documentos FOR INSERT
    WITH CHECK (auth.uid() = user_id);
```

3. Ve a **Authentication > Email Templates** y personaliza los emails de confirmación y recuperación de contraseña
4. Copia tu **Project URL** y **anon public key** desde **Settings > API**

### Paso 2: Configurar las credenciales

Abre el archivo `js/config.js` y reemplaza los valores:

```javascript
const CONFIG = {
    SUPABASE_URL: 'https://tu-proyecto.supabase.co',
    SUPABASE_ANON_KEY: 'tu-anon-key-aqui',
    CLAUDE_API_KEY: 'tu-claude-api-key', // Opcional por ahora
    MERCADOPAGO_PUBLIC_KEY: 'tu-mp-public-key', // Opcional
    // ... resto de configuración
};
```

### Paso 3: Crear repositorio en GitHub

```bash
cd lexia-v5
git init
git add .
git commit -m "Initial commit - LexIA v5"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/lexia-app.git
git push -u origin main
```

### Paso 4: Deploy en Vercel

1. Ve a [Vercel](https://vercel.com) e inicia sesión
2. Click en **Add New Project**
3. Importa tu repositorio de GitHub
4. Vercel detectará automáticamente la configuración
5. Click en **Deploy**

Tu aplicación estará disponible en: `https://tu-proyecto.vercel.app`

## 🔐 Configuración de seguridad

### Variables de entorno en Vercel

Para mayor seguridad, agrega las API keys como variables de entorno en Vercel:

1. Ve a tu proyecto en Vercel
2. Settings > Environment Variables
3. Agrega:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
   - `CLAUDE_API_KEY`
   - `MERCADOPAGO_PUBLIC_KEY`

## 📱 Uso

### Para usuarios finales

1. Visita la landing page
2. Click en "Probar 7 días gratis"
3. Registra tu cuenta
4. Comienza a usar todas las funcionalidades

### Para desarrollo

```bash
# Instalar servidor local (opcional)
npm install -g http-server

# Ejecutar
http-server

# Abrir en navegador
# http://localhost:8080
```

## 🎨 Personalización

### Modificar colores

Edita las variables CSS en `styles/landing.css` y `styles/app.css`:

```css
:root {
    --primary: #6366f1;
    --secondary: #8b5cf6;
    /* ... más colores */
}
```

### Agregar más tipos de escritos

Edita `js/config.js` en la sección `TIPOS_ESCRITOS`.

## 🔄 Actualizaciones

Para actualizar la aplicación:

```bash
git add .
git commit -m "Descripción de cambios"
git push
```

Vercel desplegará automáticamente los cambios.

## ⚠️ Notas importantes

1. **Funcionalidades de IA**: Requieren configurar la API Key de Claude (Anthropic)
2. **Pagos**: Requieren configurar Mercado Pago correctamente
3. **Emails**: Configura SMTP en Supabase para enviar emails de confirmación
4. **Prueba gratuita**: Por defecto son 7 días, configurable en `config.js`

## 🐛 Solución de problemas

### Error de autenticación
- Verifica que las credenciales de Supabase sean correctas
- Revisa la configuración de RLS en Supabase

### No se cargan los datos
- Abre la consola del navegador (F12) y verifica errores
- Confirma que las tablas existan en Supabase

### Error al registrar usuarios
- Verifica que el email template esté configurado
- Confirma que la tabla `perfiles` tenga las políticas RLS correctas

## 📄 Licencia

Todos los derechos reservados © 2024 LexIA

## 🤝 Soporte

Para soporte técnico, contacta a: [tu-email]

---

Desarrollado con ❤️ para abogados argentinos 🇦🇷
