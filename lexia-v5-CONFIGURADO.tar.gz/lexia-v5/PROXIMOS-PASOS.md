# ✅ PROYECTO CONFIGURADO - PRÓXIMOS PASOS

## 🎉 ¡Supabase ya está configurado!

Tu archivo `config.js` ya tiene las credenciales correctas:
- ✅ Project URL: https://ewbvvdaxyfwowbirtomr.supabase.co
- ✅ Anon Key: Configurada correctamente

---

## 📋 PASO 2: Crear las tablas en Supabase

### Opción A: Desde el Dashboard (Recomendado)

1. **Ve a Supabase Dashboard**
   - URL: https://supabase.com/dashboard/project/ewbvvdaxyfwowbirtomr

2. **Abre el SQL Editor**
   - Menú lateral → Ícono de código `</>` → "SQL Editor"
   - O directo: https://supabase.com/dashboard/project/ewbvvdaxyfwowbirtomr/sql

3. **Crea una nueva query**
   - Click en "+ New query"

4. **Copia y pega el SQL**
   - Abre el archivo `database.sql` del proyecto
   - Copia TODO el contenido
   - Pégalo en el editor de Supabase

5. **Ejecuta el script**
   - Click en "Run" (abajo a la derecha)
   - Espera unos segundos
   - Deberías ver: "Success. No rows returned"

### Opción B: Copiar desde aquí

Si prefieres, aquí está el SQL completo (también está en `database.sql`):

```sql
-- [El SQL completo está en el archivo database.sql]
```

---

## 🔍 Verificar que todo salió bien

Después de ejecutar el SQL:

1. **Ve a Table Editor**
   - Menú lateral → Ícono de tabla → "Table Editor"

2. **Deberías ver estas tablas:**
   - ✓ perfiles
   - ✓ expedientes
   - ✓ clientes
   - ✓ audiencias
   - ✓ documentos
   - ✓ archivos

3. **Verifica RLS (Row Level Security)**
   - Cada tabla debería tener un candado 🔒 verde
   - Esto significa que la seguridad está activa

---

## 📤 PASO 3: Subir a GitHub

### Si nunca has usado Git/GitHub:

1. **Descarga GitHub Desktop**
   - https://desktop.github.com
   - Instala y abre

2. **Inicia sesión en GitHub**
   - Si no tienes cuenta, créala en https://github.com

3. **Agrega tu proyecto**
   - En GitHub Desktop: File → Add Local Repository
   - Selecciona la carpeta `lexia-v5` que descargaste

4. **Crea el repositorio**
   - Si te pide "Create", acepta
   - Repository name: `lexia-app`
   - Description: "Asistente legal con IA"

5. **Publica en GitHub**
   - Click en "Publish repository"
   - Desmarca "Keep this code private" (o déjalo marcado si quieres privado)
   - Click en "Publish repository"

### Si ya conoces Git (por terminal):

```bash
cd ruta/a/lexia-v5

# Inicializar git
git init

# Agregar archivos
git add .

# Commit inicial
git commit -m "Initial commit - LexIA v5 configurado"

# Crear repo en GitHub primero, luego:
git remote add origin https://github.com/TU-USUARIO/lexia-app.git
git branch -M main
git push -u origin main
```

---

## 🚀 PASO 4: Deploy en Vercel

1. **Ve a Vercel**
   - https://vercel.com
   - Inicia sesión con tu cuenta de GitHub

2. **Importa el proyecto**
   - Click en "Add New..." → "Project"
   - Busca tu repositorio `lexia-app`
   - Click en "Import"

3. **Configuración del proyecto**
   - Project Name: `lexia-app` (o el que prefieras)
   - Framework Preset: Other (se detecta automático)
   - Root Directory: `./`
   - **NO cambies Build Command ni Output Directory**

4. **Deploy**
   - Click en "Deploy"
   - Espera 1-2 minutos
   - ¡Listo! 🎉

5. **Tu URL será:**
   - `https://lexia-app-tu-usuario.vercel.app`
   - O algo similar

---

## 🧪 PASO 5: Probar la aplicación

1. **Abre tu URL de Vercel**

2. **Deberías ver:**
   - ✅ Landing page de LexIA
   - ✅ Botón "Probar 7 días gratis"

3. **Crea una cuenta de prueba:**
   - Click en "Probar 7 días gratis"
   - Completa el formulario
   - Usa tu email real

4. **Verifica el email:**
   - Revisa tu bandeja de entrada
   - Click en el link de confirmación de Supabase

5. **Inicia sesión:**
   - Usa tu email y contraseña
   - Deberías ver el dashboard

6. **Prueba las funcionalidades:**
   - ✓ Crear un expediente
   - ✓ Crear un cliente
   - ✓ Usar las calculadoras
   - ✓ Navegar entre secciones

---

## 🔧 Configuraciones Opcionales

### Para activar las funciones de IA (Claude):

1. **Obtén API Key de Anthropic:**
   - https://console.anthropic.com
   - Crea cuenta → API Keys → Create Key

2. **Agrega en GitHub:**
   - Edita `js/config.js` en GitHub
   - Reemplaza `'TU_API_KEY_DE_CLAUDE'` con tu clave real
   - Commit y push

3. **Vercel desplegará automáticamente**

### Para activar pagos (Mercado Pago):

1. **Obtén credenciales:**
   - https://www.mercadopago.com.ar/developers
   - Crea aplicación
   - Obtén Public Key y Access Token

2. **Agrega en `config.js`**
   - Similar al proceso de Claude API

---

## 📞 ¿Problemas?

### Error al ejecutar SQL
→ Revisa que copiaste TODO el contenido de database.sql
→ Asegúrate de estar en el proyecto correcto de Supabase

### No recibo email de confirmación
→ Revisa spam/correo no deseado
→ En Supabase: Authentication → Settings → Email Templates

### Error al crear expediente/cliente
→ Verifica que las tablas existan
→ Confirma que RLS esté habilitado
→ Revisa la consola del navegador (F12)

### Deploy falla en Vercel
→ Verifica que el código esté en GitHub
→ Confirma que vercel.json exista
→ Revisa los logs en Vercel

---

## ✅ Checklist Final

- [ ] Supabase configurado (credenciales en config.js)
- [ ] Tablas creadas (ejecutar database.sql)
- [ ] RLS verificado (candados verdes en tablas)
- [ ] Código subido a GitHub
- [ ] Deploy en Vercel exitoso
- [ ] Landing page carga
- [ ] Registro de usuario funciona
- [ ] Email de confirmación llega
- [ ] Login funciona
- [ ] Dashboard se ve correctamente
- [ ] Puedo crear expedientes
- [ ] Puedo crear clientes
- [ ] Calculadoras funcionan

---

## 🎯 ¿Todo listo?

Una vez completado este checklist:

1. **Tu app estará funcionando al 100%** (sin IA por ahora)
2. **Puedes empezar a usarla** para gestionar expedientes y clientes
3. **Las calculadoras funcionarán** inmediatamente
4. **La IA se activa** cuando agregues la Claude API key

---

**¡Estás a solo 3 pasos de tener tu app corriendo!**
1. ✅ Supabase configurado
2. ⏳ Ejecutar SQL (5 minutos)
3. ⏳ GitHub + Vercel (10 minutos)

**Total: ~15 minutos más y está listo** 🚀

---

**Última actualización:** 19/04/2026
**Tu Project ID:** ewbvvdaxyfwowbirtomr
**Estado:** ✅ Credenciales configuradas, listo para SQL
