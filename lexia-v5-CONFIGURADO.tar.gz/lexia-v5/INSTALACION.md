# 🚀 GUÍA COMPLETA DE INSTALACIÓN - LexIA

## 📌 ANTES DE COMENZAR

Esta guía te llevará paso a paso para tener LexIA funcionando completamente.
Tiempo estimado: 30-45 minutos.

---

## PASO 1: CREAR PROYECTO EN SUPABASE (10 min)

### 1.1 Crear cuenta y proyecto
1. Ve a https://supabase.com
2. Click en "Start your project"
3. Regístrate con GitHub o email
4. Click en "New project"
5. Completa:
   - Name: `lexia-app`
   - Database Password: (crea una contraseña segura y guárdala)
   - Region: South America (São Paulo)
6. Click en "Create new project"
7. Espera 2-3 minutos mientras se crea

### 1.2 Crear las tablas de la base de datos
1. En el menú lateral, click en "SQL Editor"
2. Click en "New query"
3. Copia y pega TODO el SQL que está en README.md (sección "Paso 1: Configurar Supabase")
4. Click en "Run" (abajo a la derecha)
5. Deberías ver: "Success. No rows returned"

### 1.3 Obtener las credenciales
1. En el menú lateral, click en "Settings" (⚙️)
2. Click en "API"
3. Copia y guarda en un archivo de texto:
   - **Project URL** (ejemplo: https://xxxxx.supabase.co)
   - **anon public** (clave larga que empieza con "eyJ...")

### 1.4 Configurar autenticación por email
1. En el menú lateral, click en "Authentication"
2. Click en "Providers"
3. Verifica que "Email" esté habilitado (toggle en verde)
4. Click en "Email Templates" (menú lateral)
5. Edita "Confirm signup" y personaliza el mensaje si quieres

---

## PASO 2: CONFIGURAR EL CÓDIGO (5 min)

### 2.1 Abrir archivo de configuración
1. Abre el archivo: `js/config.js`
2. Encuentra la línea que dice: `SUPABASE_URL: 'TU_URL_DE_SUPABASE'`
3. Reemplaza `'TU_URL_DE_SUPABASE'` con tu Project URL (entre comillas)
4. Encuentra la línea: `SUPABASE_ANON_KEY: 'TU_ANON_KEY_DE_SUPABASE'`
5. Reemplaza con tu anon public key

Ejemplo:
```javascript
const CONFIG = {
    SUPABASE_URL: 'https://jejkvamiupzgwmatgrmg.supabase.co',
    SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
    // ... resto del archivo
};
```

6. Guarda el archivo

---

## PASO 3: SUBIR A GITHUB (10 min)

### 3.1 Crear repositorio en GitHub
1. Ve a https://github.com
2. Inicia sesión (o crea una cuenta si no tienes)
3. Click en el botón "+" arriba a la derecha
4. Click en "New repository"
5. Completa:
   - Repository name: `lexia-app`
   - Description: "Asistente legal con IA para abogados argentinos"
   - Privacidad: Public (o Private si prefieres)
6. **NO marques** "Add a README file"
7. Click en "Create repository"

### 3.2 Subir el código
Opción A - Usando GitHub Desktop (más fácil):
1. Descarga GitHub Desktop: https://desktop.github.com
2. Instala y abre GitHub Desktop
3. File > Add local repository
4. Selecciona la carpeta `lexia-v5`
5. Click en "Create repository"
6. Click en "Publish repository"
7. Selecciona tu cuenta y confirma

Opción B - Usando línea de comandos:
```bash
# Abre la terminal en la carpeta lexia-v5
cd ruta/a/lexia-v5

# Inicializa git
git init

# Agrega todos los archivos
git add .

# Crea el primer commit
git commit -m "Initial commit - LexIA v5"

# Conecta con GitHub (reemplaza TU-USUARIO)
git remote add origin https://github.com/TU-USUARIO/lexia-app.git

# Sube el código
git branch -M main
git push -u origin main
```

---

## PASO 4: DEPLOY EN VERCEL (10 min)

### 4.1 Crear cuenta en Vercel
1. Ve a https://vercel.com
2. Click en "Sign Up"
3. Elige "Continue with GitHub"
4. Autoriza a Vercel

### 4.2 Importar proyecto
1. En el dashboard de Vercel, click en "Add New..."
2. Click en "Project"
3. Deberías ver tu repositorio `lexia-app`
4. Click en "Import"

### 4.3 Configurar proyecto
1. Project Name: puedes dejarlo como está o cambiarlo
2. Framework Preset: detectará automáticamente (Other)
3. Root Directory: `.` (dejar como está)
4. **NO necesitas configurar Build Command ni Output Directory**
5. Click en "Deploy"

### 4.4 Esperar el deploy
1. Vercel comenzará a construir tu proyecto
2. Espera 1-2 minutos
3. Cuando veas "🎉 Congratulations!", tu app está lista

### 4.5 Ver tu aplicación
1. Click en "Visit" o en la URL que aparece
2. Tu app estará en: `https://tu-proyecto.vercel.app`

---

## PASO 5: PROBAR LA APLICACIÓN (5 min)

### 5.1 Primera prueba
1. Ve a tu URL de Vercel
2. Deberías ver la landing page de LexIA
3. Click en "Probar 7 días gratis"

### 5.2 Crear cuenta de prueba
1. Completa el formulario:
   - Nombre: Tu nombre
   - Email: tu email real
   - Contraseña: mínimo 6 caracteres
   - Matrícula: (opcional)
2. Click en "Comenzar prueba gratuita"

### 5.3 Verificar email
1. Ve a tu bandeja de entrada
2. Busca el email de confirmación de Supabase
3. Click en el link de confirmación

### 5.4 Iniciar sesión
1. Vuelve a tu app
2. Inicia sesión con tu email y contraseña
3. ¡Deberías ver el dashboard!

---

## PASO 6: CONFIGURACIONES OPCIONALES

### 6.1 Configurar Claude API (IA)
Para habilitar las funciones de IA:
1. Ve a https://console.anthropic.com
2. Crea una cuenta
3. Genera una API Key
4. Agrégala en `js/config.js`:
```javascript
CLAUDE_API_KEY: 'tu-api-key-de-claude',
```

### 6.2 Configurar Mercado Pago (Pagos)
Para habilitar suscripciones:
1. Ve a https://www.mercadopago.com.ar/developers
2. Crea una aplicación
3. Obtén tus credenciales de TEST
4. Agrégalas en `js/config.js`:
```javascript
MERCADOPAGO_PUBLIC_KEY: 'tu-public-key',
```

### 6.3 Dominio personalizado (opcional)
En Vercel:
1. Ve a tu proyecto > Settings > Domains
2. Click en "Add"
3. Ingresa tu dominio (ejemplo: lexia.com.ar)
4. Sigue las instrucciones para configurar DNS

---

## ✅ CHECKLIST FINAL

Verifica que todo esté funcionando:

- [ ] La landing page carga correctamente
- [ ] Puedes crear una cuenta nueva
- [ ] Recibes el email de confirmación
- [ ] Puedes iniciar sesión
- [ ] Ves el dashboard con las estadísticas
- [ ] Puedes navegar entre secciones
- [ ] Las calculadoras funcionan
- [ ] No hay errores en la consola del navegador (F12)

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### "Error de conexión"
- Verifica que las credenciales de Supabase sean correctas en config.js
- Revisa que la URL no tenga espacios o caracteres extra

### "No puedo crear cuenta"
- Verifica que las tablas existan en Supabase (SQL Editor > Tables)
- Revisa que RLS esté habilitado (en cada tabla)

### "No recibo el email de confirmación"
- Revisa spam/correo no deseado
- En Supabase: Authentication > Settings > verifica que SMTP esté configurado
- Para desarrollo: puedes desactivar la confirmación de email temporalmente

### "La app no carga después del deploy"
- Abre las DevTools (F12) y revisa la consola
- En Vercel, ve a tu proyecto > Deployments > Latest > View Function Logs
- Verifica que config.js tenga las credenciales correctas

### "Error al guardar datos"
- Abre la consola (F12) y busca errores
- Verifica las políticas RLS en Supabase
- Confirma que estés autenticado correctamente

---

## 📞 ¿NECESITAS AYUDA?

Si tienes problemas:
1. Revisa esta guía nuevamente
2. Verifica la consola del navegador (F12)
3. Revisa los logs en Vercel y Supabase
4. Consulta la documentación oficial:
   - Supabase: https://supabase.com/docs
   - Vercel: https://vercel.com/docs

---

## 🎉 ¡LISTO!

Tu aplicación LexIA está funcionando. Ahora puedes:
- Personalizar los colores y diseño
- Agregar más funcionalidades
- Configurar las APIs opcionales (Claude, Mercado Pago)
- Invitar a otros abogados a probarla

**¡Éxitos con tu proyecto! 🚀**
