# ✅ Checklist de Deployment - LexIA

## Pre-deployment

### Configuración de Supabase
- [ ] Proyecto de Supabase creado
- [ ] Base de datos configurada (ejecutar database.sql)
- [ ] Tablas creadas correctamente
- [ ] Políticas RLS habilitadas
- [ ] Storage bucket creado
- [ ] URL y anon key copiadas
- [ ] Email templates configurados
- [ ] SMTP configurado (opcional, para emails personalizados)

### Configuración del Código
- [ ] Archivo `js/config.js` actualizado con credenciales de Supabase
- [ ] Claude API key agregada (si vas a usar IA)
- [ ] Mercado Pago keys agregadas (si vas a usar pagos)
- [ ] URLs de producción configuradas
- [ ] Precio de suscripción actualizado
- [ ] Días de trial configurados

### GitHub
- [ ] Repositorio creado en GitHub
- [ ] Código subido al repositorio
- [ ] README.md actualizado con tu información
- [ ] .gitignore configurado correctamente
- [ ] Commit inicial realizado

### Vercel
- [ ] Cuenta de Vercel creada
- [ ] Proyecto importado desde GitHub
- [ ] Variables de entorno configuradas (opcional)
- [ ] Deploy exitoso
- [ ] URL de producción funcionando

---

## Testing - Funcionalidades Básicas

### Autenticación
- [ ] Página de landing carga correctamente
- [ ] Formulario de registro funciona
- [ ] Email de confirmación llega
- [ ] Link de confirmación funciona
- [ ] Login con credenciales funciona
- [ ] Recuperación de contraseña funciona
- [ ] Logout funciona
- [ ] Redirección automática si no hay sesión

### Dashboard
- [ ] Dashboard carga después de login
- [ ] Estadísticas se muestran (pueden estar en 0)
- [ ] Banner de trial se muestra
- [ ] Días restantes se calculan correctamente
- [ ] Acciones rápidas funcionan
- [ ] Navegación entre secciones funciona

### Gestión de Expedientes
- [ ] Botón "Nuevo expediente" abre modal
- [ ] Formulario de expediente se puede completar
- [ ] Expediente se guarda en Supabase
- [ ] Lista de expedientes se actualiza
- [ ] Detalles de expediente se pueden ver
- [ ] Expediente se puede eliminar
- [ ] Contador en dashboard se actualiza

### Gestión de Clientes
- [ ] Botón "Nuevo cliente" abre modal
- [ ] Formulario de cliente funciona
- [ ] Cliente se guarda correctamente
- [ ] Lista de clientes se muestra
- [ ] Detalles de cliente se pueden ver
- [ ] Cliente se puede eliminar
- [ ] Contador en dashboard se actualiza

### Calculadoras
- [ ] Calculadora de indemnización funciona
- [ ] Cálculo es matemáticamente correcto
- [ ] Resultados se muestran correctamente
- [ ] Calculadora de alimentos funciona
- [ ] Calculadora de accidente funciona
- [ ] Tabs entre calculadoras funcionan

### Navegación
- [ ] Todas las secciones son accesibles
- [ ] Menú lateral funciona
- [ ] Íconos se muestran correctamente
- [ ] Responsive en móvil funciona
- [ ] No hay errores en consola (F12)

---

## Testing - Funcionalidades de IA (Requiere Claude API)

### Análisis de PDFs
- [ ] Zona de upload funciona
- [ ] Drag & drop funciona
- [ ] PDF se sube correctamente
- [ ] Análisis se ejecuta (puede tomar 30-60s)
- [ ] Resultado se muestra
- [ ] Mensaje de error si API no configurada

### Estrategia Procesal
- [ ] Formulario carga expedientes disponibles
- [ ] Tipos de estrategia se pueden seleccionar
- [ ] Generación funciona
- [ ] Resultado se muestra correctamente
- [ ] Se puede guardar o copiar

### Escritos Judiciales
- [ ] Tipos de escrito disponibles
- [ ] Expedientes se pueden vincular
- [ ] Generación funciona
- [ ] Formato del escrito es correcto
- [ ] Disclaimer legal incluido
- [ ] Se puede copiar o descargar

### Cartas Documento
- [ ] Formulario completo funciona
- [ ] Motivos predefinidos disponibles
- [ ] Generación funciona
- [ ] Formato de carta correcto

### Contratos
- [ ] Tipos de contrato disponibles
- [ ] Generación funciona
- [ ] Base legal citada correctamente
- [ ] Estructura de contrato adecuada

---

## Testing - Rendimiento

### Tiempos de carga
- [ ] Landing page < 2 segundos
- [ ] App login < 1 segundo
- [ ] Dashboard < 2 segundos
- [ ] Listados < 1 segundo
- [ ] Generación IA < 60 segundos

### Optimización
- [ ] Imágenes optimizadas
- [ ] CSS minificado (opcional)
- [ ] JS minificado (opcional)
- [ ] Sin errores en Lighthouse
- [ ] Puntuación > 80 en Performance

---

## Testing - Seguridad

### RLS (Row Level Security)
- [ ] Usuario A no puede ver datos de usuario B
- [ ] Intentos de acceso no autorizado fallan
- [ ] Políticas RLS funcionan correctamente
- [ ] Storage policies funcionan

### Autenticación
- [ ] Tokens JWT se manejan correctamente
- [ ] Sesión expira después de inactividad
- [ ] Contraseñas se hashean
- [ ] No hay credenciales en código cliente

### HTTPS
- [ ] Sitio sirve sobre HTTPS
- [ ] Redirección HTTP → HTTPS funciona
- [ ] Certificado SSL válido

---

## Testing - Compatibilidad

### Navegadores Desktop
- [ ] Chrome (última versión)
- [ ] Firefox (última versión)
- [ ] Safari (última versión)
- [ ] Edge (última versión)

### Navegadores Móvil
- [ ] Chrome móvil
- [ ] Safari iOS
- [ ] Firefox móvil

### Dispositivos
- [ ] Desktop 1920x1080
- [ ] Laptop 1366x768
- [ ] Tablet 768x1024
- [ ] Móvil 375x667

---

## Post-deployment

### Monitoreo
- [ ] Analytics configurado (opcional)
- [ ] Error tracking configurado (opcional)
- [ ] Uptime monitoring configurado (opcional)

### Documentación
- [ ] README actualizado
- [ ] Guías de uso creadas
- [ ] Changelog iniciado

### Marketing
- [ ] Landing page optimizada para SEO
- [ ] Meta tags configurados
- [ ] Open Graph tags configurados
- [ ] Favicon agregado

### Backup
- [ ] Backup de base de datos configurado
- [ ] Código versionado en Git
- [ ] Configuración documentada

---

## Issues Comunes y Soluciones

### "Supabase no configurado"
**Solución:** Verifica credenciales en config.js

### "No se cargan datos"
**Solución:** Revisa políticas RLS en Supabase

### "Error 401 Unauthorized"
**Solución:** Sesión expirada, vuelve a loguearte

### "Error al crear usuario"
**Solución:** Verifica tabla perfiles y trigger

### "Claude API error"
**Solución:** Verifica API key y créditos

### "Mercado Pago no funciona"
**Solución:** Configura credenciales correctamente

---

## Métricas de Éxito

### Técnicas
- [ ] 99% uptime
- [ ] < 2s tiempo de carga promedio
- [ ] 0 errores críticos en producción
- [ ] > 80 Lighthouse score

### Negocio
- [ ] X usuarios registrados en primera semana
- [ ] Y% conversión de trial a pago
- [ ] Z Net Promoter Score (NPS)

---

## Próximos Pasos

Después del deployment exitoso:

1. **Semana 1-2:**
   - [ ] Monitorear errores
   - [ ] Recopilar feedback de usuarios
   - [ ] Ajustar UI según uso real

2. **Mes 1:**
   - [ ] Implementar features solicitados
   - [ ] Optimizar rendimiento
   - [ ] Mejorar documentación

3. **Trimestre 1:**
   - [ ] Agregar más tipos de documentos
   - [ ] Integrar más calculadoras
   - [ ] Mejorar IA con feedback

---

**Fecha de deployment:** _______________
**Deployado por:** _______________
**URL producción:** _______________
**Versión:** 5.0.0
