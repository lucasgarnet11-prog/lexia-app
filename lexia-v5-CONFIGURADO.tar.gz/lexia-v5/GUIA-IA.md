# 🤖 Guía de Funcionalidades de IA - LexIA

## Configuración de Claude API

Para habilitar las funcionalidades de IA, necesitas una API Key de Anthropic.

### Obtener API Key

1. Ve a https://console.anthropic.com
2. Crea una cuenta o inicia sesión
3. Ve a "API Keys"
4. Click en "Create Key"
5. Copia la clave generada

### Configurar en la aplicación

Abre `js/config.js` y reemplaza:

```javascript
CLAUDE_API_KEY: 'tu-claude-api-key',
```

Con tu clave real:

```javascript
CLAUDE_API_KEY: 'sk-ant-api03-xxxxxxxxxxxxxxxxxxxxxx',
```

---

## Funcionalidades de IA Disponibles

### 1. 📄 Análisis de Expedientes PDF

**Qué hace:**
- Lee y extrae información de PDFs
- Identifica partes, tipo de proceso, hechos relevantes
- Detecta cuestiones jurídicas principales
- Sugiere normativa aplicable
- Identifica etapa procesal

**Cómo usar:**
1. Ve a "Análisis de PDFs"
2. Arrastra un PDF del expediente o haz click para seleccionar
3. Espera el análisis (puede tomar 30-60 segundos)
4. Revisa el análisis generado
5. Guarda o exporta el resultado

**Ejemplo de salida:**
```
RESUMEN EJECUTIVO:
Juicio laboral por despido sin causa de empleado con 5 años de antigüedad...

PARTES:
Actor: Juan García (DNI 12.345.678)
Demandado: Empresa XYZ SA (CUIT 30-12345678-9)

TIPO DE PROCESO:
Despido sin causa - Reclamo de indemnización

HECHOS RELEVANTES:
- Fecha de ingreso: 15/03/2019
- Fecha de despido: 20/08/2024
- Última remuneración: $500.000
...
```

---

### 2. ⚖️ Estrategia Procesal

**Qué hace:**
- Analiza la situación del expediente
- Identifica fortalezas y debilidades
- Propone estrategias concretas
- Sugiere líneas argumentales
- Recomienda acciones inmediatas

**Tipos de estrategia:**
- **General**: Análisis completo del caso
- **Defensiva**: Enfoque en proteger posición
- **Ofensiva**: Enfoque en avanzar agresivamente
- **Negociación**: Preparación para acuerdos

**Cómo usar:**
1. Ve a "Estrategia"
2. Selecciona un expediente existente
3. Elige el tipo de estrategia
4. Agrega contexto adicional (opcional)
5. Click en "Generar estrategia"

**Ejemplo de salida:**
```
ANÁLISIS DE LA SITUACIÓN ACTUAL

Fortalezas:
✓ Antigüedad comprobada mediante recibos de sueldo
✓ Despido sin expresión de causa
✓ Montos salariales documentados

Debilidades:
⚠ Falta acreditar comunicación fehaciente del despido
⚠ No hay prueba de tareas efectivamente realizadas

OBJETIVO ESTRATÉGICO
Obtener indemnización completa por despido sin causa...

PLAN DE ACCIÓN
1. Inmediato (1-7 días):
   - Intimar fehacientemente reconocimiento del vínculo
   - Solicitar certificación de servicios y remuneraciones
...
```

---

### 3. ✍️ Redacción de Escritos Judiciales

**Tipos disponibles:**
- Demanda
- Contestación de demanda
- Recurso de apelación
- Recurso de revocatoria
- Alegato
- Memorial
- Ofrecimiento de prueba
- Incidente

**Cómo usar:**
1. Ve a "Escritos Judiciales"
2. Selecciona el tipo de escrito
3. Opcionalmente vincula a un expediente
4. Describe los hechos, fundamentos y peticiones
5. Click en "Generar escrito"
6. Revisa el borrador generado
7. Edita y personaliza según necesidad

**Ejemplo de input:**
```
Tipo: Demanda
Detalles: 
Actor: Juan García, DNI 12.345.678, domiciliado en Calle 123, CABA
Demandado: Empresa XYZ SA, CUIT 30-12345678-9
Hechos: Despido sin causa el 20/08/2024, antigüedad 5 años, 
última remuneración $500.000
Reclamo: Indemnización por despido, preaviso, integración mes despido, 
vacaciones no gozadas, SAC proporcional
```

**Ejemplo de output:**
```
SEÑOR JUEZ:

    Juan García, DNI 12.345.678, argentino, domiciliado en Calle 123, 
    Ciudad Autónoma de Buenos Aires, constituyendo domicilio procesal en...

OBJETO

    Vengo por la presente a promover formal demanda contra Empresa XYZ SA...

I. HECHOS
    
    1. Con fecha 15 de marzo de 2019, mi representado ingresó a prestar 
    servicios en relación de dependencia para la demandada...
...

⚠️ BORRADOR - Debe ser revisado por el abogado profesional
```

---

### 4. 📨 Cartas Documento

**Motivos predefinidos:**
- Intimación de pago
- Rescisión de contrato
- Notificación de despido
- Reclamo por daños
- Intimación de cumplimiento
- Otro motivo

**Cómo usar:**
1. Ve a "Cartas Documento"
2. Completa datos del destinatario
3. Selecciona el motivo
4. Describe los hechos y lo que requieres
5. Click en "Generar carta documento"

**Ejemplo de output:**
```
                                        Buenos Aires, 18 de abril de 2026

Señor
JUAN PÉREZ
Presente

De mi consideración:

    Por medio de la presente, en mi carácter de letrado patrocinante 
    de mi mandante EMPRESA XYZ SA, me dirijo a Ud. a fin de intimar...

    PRIMERO: Que con fecha 15/10/2025 celebró con mi mandante un 
    contrato de locación de servicios...
    
    SEGUNDO: Que conforme cláusula tercera del contrato, se comprometió
    a abonar la suma de $100.000 mensuales...
    
    Por todo lo expuesto, vengo a intimarlo para que en el plazo 
    de 48 horas hábiles...
```

---

### 5. 📄 Contratos

**Tipos disponibles:**
- Compraventa (CCyCN Art. 1123-1157)
- Locación (CCyCN Art. 1187-1227)
- Trabajo (LCT Ley 20.744)
- Prestación de servicios (CCyCN Art. 1251-1279)
- Mutuo (CCyCN Art. 1525-1534)
- Comodato (CCyCN Art. 1533-1541)
- Donación (CCyCN Art. 1542-1573)
- Sociedad (Ley 19.550)
- Mandato (CCyCN Art. 1319-1334)

**Cómo usar:**
1. Ve a "Contratos"
2. Selecciona el tipo
3. Describe las partes (nombres, DNI, domicilios)
4. Describe cláusulas y condiciones específicas
5. Click en "Generar contrato"

---

### 6. 🎓 Casos Prácticos

**Áreas disponibles:**
- Derecho Laboral
- Derecho Civil
- Derecho de Familia
- Derecho Comercial

**Qué incluye cada caso:**
- Narración detallada de hechos
- Personajes ficticios
- Documentación simulada
- Preguntas para resolver
- Pistas metodológicas

**Cómo usar:**
1. Ve a "Casos Prácticos"
2. Selecciona el área de derecho
3. Click en "Iniciar caso"
4. Lee el caso completo
5. Intenta resolverlo
6. Compara con la solución sugerida

---

## 🔒 Privacidad y Seguridad

**Datos enviados a Claude API:**
- Contenido de documentos que solicites analizar
- Información de expedientes para estrategias
- Textos que ingreses para generar escritos

**NO se envía:**
- Datos de autenticación
- Información de otros usuarios
- Archivos no relacionados con la función específica

**Recomendaciones:**
- Revisa siempre los documentos antes de subirlos
- Elimina información ultra-sensible si no es necesaria
- Los datos procesados NO se almacenan permanentemente en Claude

---

## 💡 Mejores Prácticas

### Para análisis de PDFs
✓ Usa PDFs de buena calidad (no escaneados borrosos)
✓ Asegúrate que el PDF contenga texto seleccionable
✓ Evita PDFs de más de 50 páginas (divide si es necesario)

### Para estrategias
✓ Proporciona contexto completo
✓ Menciona plazos críticos
✓ Indica objetivos específicos del cliente
✓ Actualiza si hay nuevos hechos

### Para escritos
✓ Sé específico en los hechos
✓ Menciona pruebas disponibles
✓ Indica artículos de ley si los conoces
✓ SIEMPRE revisa y personaliza el borrador

### Para contratos
✓ Detalla todas las condiciones económicas
✓ Especifica plazos claramente
✓ Menciona garantías si aplican
✓ Revisa cláusulas de resolución de conflictos

---

## ⚠️ Limitaciones Importantes

1. **No reemplaza el criterio profesional**
   - Los documentos son BORRADORES
   - Requieren revisión legal
   - Pueden tener errores

2. **No incluye jurisprudencia**
   - Por diseño, no cita fallos específicos
   - Debes agregar jurisprudencia manualmente
   - Consulta bases de datos especializadas

3. **Legislación actualizada hasta enero 2025**
   - Reformas posteriores no están incluidas
   - Verifica vigencia de normas citadas
   - Consulta boletín oficial para cambios

4. **Contexto limitado**
   - Claude analiza solo lo que le envías
   - No tiene acceso a otros documentos del expediente
   - Proporciona toda la información relevante

---

## 🆘 Solución de Problemas

### "Claude API no configurada"
- Verifica que agregaste la API Key en config.js
- Confirma que la clave es válida
- Revisa que no haya espacios extra

### "Error al generar documento"
- Verifica tu conexión a internet
- Confirma que tu API Key tenga créditos
- Revisa la consola (F12) para más detalles

### "Análisis incompleto"
- El PDF puede estar mal formado
- Intenta con un PDF más pequeño
- Asegúrate que el PDF tenga texto seleccionable

### "Respuesta muy general"
- Proporciona más detalles en el input
- Especifica el contexto completo
- Menciona fechas, montos, partes específicas

---

## 💰 Costos de API

Claude API cobra por tokens (palabras aproximadamente):

- **Análisis de PDF**: ~2.000-4.000 tokens (~$0.01-0.02 USD)
- **Estrategia**: ~3.000-5.000 tokens (~$0.015-0.025 USD)
- **Escrito judicial**: ~3.000-6.000 tokens (~$0.015-0.03 USD)
- **Contrato**: ~2.000-4.000 tokens (~$0.01-0.02 USD)

**Estimado mensual** (uso moderado):
- 20 análisis + 30 documentos ≈ $1-2 USD/mes

Revisa precios actuales en: https://www.anthropic.com/pricing

---

## 📞 Soporte

Si tienes problemas con las funcionalidades de IA:

1. Revisa esta guía
2. Verifica configuración en config.js
3. Consulta la consola del navegador (F12)
4. Revisa logs de API en console.anthropic.com

---

**Última actualización:** Abril 2026
**Versión de Claude:** Sonnet 4 (claude-sonnet-4-20250514)
